import networkx as nx
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, jsonify
import io
import base64

app = Flask(__name__)

class SimpleTravelPlanner:
    def __init__(self):
        # Create separate graphs for different modes
        self.graphs = {
            'car': nx.Graph(),
            'train': nx.Graph(),
            'plane': nx.Graph()
        }
        self._add_cities_and_routes()

    def _add_cities_and_routes(self):
        # Major US cities with their coordinates and popular tourist spots
        cities = {
            "New York": {
                "pos": (40.7128, -74.0060),
                "attractions": ["Times Square", "Statue of Liberty", "Central Park"]
            },
            "Los Angeles": {
                "pos": (34.0522, -118.2437),
                "attractions": ["Hollywood Sign", "Universal Studios", "Venice Beach"]
            },
            "Chicago": {
                "pos": (41.8781, -87.6298),
                "attractions": ["Millennium Park", "Navy Pier", "Art Institute"]
            },
            "Miami": {
                "pos": (25.7617, -80.1918),
                "attractions": ["South Beach", "Miami Beach", "Little Havana"]
            },
            "San Francisco": {
                "pos": (37.7749, -122.4194),
                "attractions": ["Golden Gate Bridge", "Alcatraz", "Fisherman's Wharf"]
            }
        }

        # Add cities to all graphs
        for mode in self.graphs:
            for city, data in cities.items():
                self.graphs[mode].add_node(city, pos=data["pos"], attractions=data["attractions"])

        # Routes with distances (km), time (hours), and cost ($) for different modes
        routes = {
            'car': [
                ("New York", "Chicago", {"distance": 1145, "time": 12, "cost": 120}),
                ("Chicago", "Los Angeles", {"distance": 2815, "time": 30, "cost": 300}),
                ("Los Angeles", "San Francisco", {"distance": 615, "time": 6, "cost": 65}),
                ("New York", "Miami", {"distance": 2100, "time": 22, "cost": 220}),
                ("Miami", "Chicago", {"distance": 1900, "time": 20, "cost": 200})
            ],
            'train': [
                ("New York", "Chicago", {"distance": 1145, "time": 20, "cost": 150}),
                ("Chicago", "Los Angeles", {"distance": 2815, "time": 43, "cost": 280}),
                ("Los Angeles", "San Francisco", {"distance": 615, "time": 12, "cost": 90}),
                ("New York", "Miami", {"distance": 2100, "time": 28, "cost": 180}),
                ("Miami", "Chicago", {"distance": 1900, "time": 25, "cost": 170})
            ],
            'plane': [
                ("New York", "Chicago", {"distance": 1145, "time": 2.5, "cost": 250}),
                ("Chicago", "Los Angeles", {"distance": 2815, "time": 4.5, "cost": 400}),
                ("Los Angeles", "San Francisco", {"distance": 615, "time": 1.5, "cost": 200}),
                ("New York", "Miami", {"distance": 2100, "time": 3, "cost": 300}),
                ("Miami", "Chicago", {"distance": 1900, "time": 3, "cost": 280})
            ]
        }

        # Add routes to respective graphs
        for mode, route_list in routes.items():
            self.graphs[mode].add_edges_from(route_list)

    def get_cities(self):
        """Get list of all cities with their attractions"""
        cities = []
        for city in self.graphs['car'].nodes():  # Use any graph as cities are same in all
            cities.append({
                'name': city,
                'attractions': self.graphs['car'].nodes[city]['attractions']
            })
        return cities

    def find_route(self, start_city, end_city, mode):
        """Find the shortest route between two cities for given mode"""
        try:
            graph = self.graphs[mode]
            path = nx.shortest_path(graph, start_city, end_city, weight='distance')
            
            # Calculate total distance, time and cost
            total_distance = 0
            total_time = 0
            total_cost = 0
            route_info = []

            for i in range(len(path)-1):
                edge_data = graph[path[i]][path[i+1]]
                total_distance += edge_data['distance']
                total_time += edge_data['time']
                total_cost += edge_data['cost']
                route_info.append({
                    'from': path[i],
                    'to': path[i+1],
                    'distance': edge_data['distance'],
                    'time': edge_data['time'],
                    'cost': edge_data['cost']
                })

            # Generate route visualization
            plt.figure(figsize=(12, 8))
            pos = nx.get_node_attributes(graph, 'pos')
            
            # Draw all nodes and edges
            nx.draw_networkx_nodes(graph, pos, node_color='lightblue', node_size=700)
            nx.draw_networkx_edges(graph, pos, alpha=0.2)
            nx.draw_networkx_labels(graph, pos)
            
            # Highlight the route
            path_edges = list(zip(path[:-1], path[1:]))
            nx.draw_networkx_edges(graph, pos, edgelist=path_edges, 
                                 edge_color='red', width=2)

            plt.title(f"Travel Route Map - {mode.capitalize()} Route")
            plt.axis('off')
            
            # Convert plot to base64 string
            img = io.BytesIO()
            plt.savefig(img, format='png', bbox_inches='tight')
            img.seek(0)
            plt.close()
            
            return {
                'success': True,
                'path': path,
                'total_distance': total_distance,
                'total_time': total_time,
                'total_cost': total_cost,
                'route_info': route_info,
                'map_image': base64.b64encode(img.getvalue()).decode()
            }

        except nx.NetworkXNoPath:
            return {
                'success': False,
                'error': 'No route found between these cities'
            }

# Create global planner instance
planner = SimpleTravelPlanner()

@app.route('/')
def home():
    return render_template('index.html', cities=planner.get_cities())

@app.route('/find_route', methods=['POST'])
def find_route():
    data = request.get_json()
    start = data.get('start')
    end = data.get('end')
    mode = data.get('mode', 'car')  # Default to car if mode not specified
    
    if not start or not end:
        return jsonify({'success': False, 'error': 'Please select both cities'})
    
    result = planner.find_route(start, end, mode)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, port=5000) 